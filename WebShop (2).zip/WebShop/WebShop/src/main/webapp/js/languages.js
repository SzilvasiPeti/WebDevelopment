$(document).ready(function() {
	$("#lang_en").click(function(){
		$.post("IndexServlet",{
        	lang : "en"
        });
        open("IndexServlet","_self");
    });
	$("#lang_hu").click(function(){
		$.post("IndexServlet",{
			lang : "hu_HU"
        });
		open("IndexServlet","_self");
	});
	$.i18n.properties({ 
		name: 'Messages', 
		path: 'languages/', 
		mode: 'both', 
		language: getCookie("language"), 
		callback: function() { 
			$("#webSite").text($.i18n.prop('webSite'));
			$("#home").text($.i18n.prop('home'));
			$("#loginMenu").text($.i18n.prop('loginMenu'));
			$("#logoutMenu").text($.i18n.prop('logoutMenu'));
			$("#singUp").text($.i18n.prop('singUp'));
			$("#welcome").text($.i18n.prop('welcome'));
			$("#pfooter").text($.i18n.prop('pfooter'));
		}
	});
});