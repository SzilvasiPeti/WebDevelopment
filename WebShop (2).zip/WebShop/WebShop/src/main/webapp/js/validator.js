$(document).ready(function(){
	function getCookie(cname) {
		var name = cname + "=";
		var decodedCookie = decodeURIComponent(document.cookie);
		var ca = decodedCookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ') {
				c = c.substring(1);
			}
			if (c.indexOf(name) == 0) {
				return c.substring(name.length, c.length);
			}
		}
		return "";
	}
	var selectLanguage;

	var atLeast;
	var accountNull;
	var passwordNull;
	var passwordLength;
	var passwordAlpha;
	var cpasswordNull;
	var passwordEqual;
	var ok;

	$.i18n.properties({
		name : 'text',
		path : 'bundle/',
		mode : 'both',
		language : getCookie("kuki1"),
		callback : function() {
			atLeast = $.i18n.prop('atleast');
			accountNull = $.i18n.prop('accountnull');
			passwordNull = $.i18n.prop('passwordnull');
			passwordLength = $.i18n.prop('passwordlength');
			passwordAlpha = $.i18n.prop('passwordalpha');
			cpasswordNull = $.i18n.prop('cpasswordNull');
			passwordEqual = $.i18n.prop('passwordEqual');
			ok = $.i18n.prop('ok');
		}
	});
	$.validator.addMethod('mypassword', function(value, element) {
		return this.optional(element) || value.match(/[a-z]/)
				&& value.match(/[0-9]/) || value.match(/[A-Z]/)
				&& value.match(/[0-9]/) || value.match(/[a-z]/)
				&& value.match(/[A-Z]/)
	}, "" + atLeast);
	$("#myform").validate({
		rules : {
			confirmPwd : {
				required: true,
				equalTo: "#pwd"
			},
			pwd : {
				required : true,
				minlength : 8,
				mypassword : true,
				alphanumeric : true
			}
		},
		wrapper: 'div',
		messages : {
			confirmPwd : {
				required: "" + cpasswordNull,
				equalTo: "" + passwordEqual
			},
			pwd : {
				required : "" + passwordNull,
				minlength : "" + passwordLength,
				alphanumeric : "" + passwordAlpha,
			}
		}
	});
	var pwd = $("#pwd").val();
	var confirmPwd = $("#cPwd").val();
	if(pwd === confirmPwd){
		$("#pwdEq").attr("class","");
	}


});