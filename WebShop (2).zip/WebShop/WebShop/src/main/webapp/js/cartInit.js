$(function () {
	 function getCookie(cname) {
			var name = cname + "=";
			var decodedCookie = decodeURIComponent(document.cookie);
			var ca = decodedCookie.split(';');
			for (var i = 0; i < ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0) == ' ') {
					c = c.substring(1);
				}
				if (c.indexOf(name) == 0) {
					return c.substring(name.length, c.length);
				}
			}
			return "";
		}

    $('.my-cart-btn').myCart({
      currencySymbol: 'Ft',
      classCartIcon: 'my-cart-icon',
      classCartBadge: 'my-cart-badge',
      classProductQuantity: 'my-product-quantity',
      classProductRemove: 'my-product-remove',
      classCheckoutCart: 'my-cart-checkout',
      classClearCart: 'my-cart-checkout',
      affixCartIcon: true,
      showCheckoutModal: true,
      numberOfDecimals: 2,
      cartItems: getCookie("cartItems"),
      checkoutCart: function(products, totalPrice, totalQuantity) {
        var checkoutString = "Total Price: " + totalPrice + "\nTotal Quantity: " + totalQuantity;
        //checkoutString += "\n\n id \t name \t summary \t price \t quantity \t image path";
        $.each(products, function(){
          checkoutString += ("\n " + this.id + " \t " + this.name + " \t " + this.summary + " \t " + this.price + " \t " + this.quantity + " \t " + this.image);
        });
        //alert(checkoutString);
        //console.log("checking out", products, totalPrice, totalQuantity);

        $('body').append(
                '<div class="modal fade" id="successCheckoutModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel">' +
                '<div class="modal-dialog" role="document">' +
                '<div class="modal-content">' +
                '<div class="modal-header">' +
                '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                '<h4 class="modal-title" id="modalLabel"><span class="glyphicon glyphicon-ok"></span> <span class="thank"></span></h4>' +
                '</div>' +
                '<div class="modal-body">' +
                '<div class="alert alert-success"><span id="yourOrderSuccess" class="yourOrderSuccess"></span></div>' +
                '</div>' +
                '<div class="modal-footer">' +
                '<button type="button" class="btn btn-default" data-dismiss="modal"><span class="close1"></span></button>' +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>'
            );

        $.i18n.properties({
            name: 'text',
            path: 'bundle/',
            mode: 'both',
            language: getCookie("kuki1"),
            callback: function () {
                $(".thank").text($.i18n.prop('thank'));
                $(".yourOrderSuccess").text($.i18n.prop('yourOrderSuccess'));
                $(".close1").text($.i18n.prop('close'));
            }
        });
        //$('#successCheckoutModal').modal('show');
        console.log("checking out", products, totalPrice, totalQuantity);
        document.cookie = "cartItems=; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
        $.post("/product",
            {
                checkoutString: checkoutString
            });
      },
    });



  });
