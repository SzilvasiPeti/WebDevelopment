package com.example.WebShop.controllers;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.WebShop.models.Product;
import com.example.WebShop.persistence.ProductDao;

@Controller
public class ProductUploaderController {

	private static Logger LOGGER = LogManager.getLogger();
	@Autowired
	private ProductDao productDAO;
	private Cookie cookie1;
	private String language1;

	@RequestMapping(value = ("/logged"))
	public String Logged(@RequestParam(required=false) String language,@CookieValue(required = false) String kuki1,Model model, HttpServletResponse response, HttpServletRequest request){
		List<Product> productList = productDAO.getAllProducts();

		HttpSession accountSession = request.getSession();
		//accountSession.getAttribute("account");

		cookie1 = new Cookie("kuki1", language);
		response.addCookie(cookie1);
		if(accountSession.getAttribute("account") == null){
			return "redirect:/login";
		}
		else if(language == null){
			return "logged?language="+language+"#";
		}
		else if(language.equals("hu_HU")){
			model.addAttribute("hu", true);
		}else{
			model.addAttribute("hu",false);
		}
		model.addAttribute("list", productList);
		language1 = language;

		return "logged";
	}
	@RequestMapping(value = ("/product"))
	public String Product(@RequestParam(required=false) String checkoutString){
		LOGGER.info(checkoutString);
		return "logged";
	}
	public Cookie getCookie1() {
		return cookie1;
	}
	public void setCookie1(Cookie cookie1) {
		this.cookie1 = cookie1;
	}
	public String getLanguage1(){
		return language1;
	}



}
