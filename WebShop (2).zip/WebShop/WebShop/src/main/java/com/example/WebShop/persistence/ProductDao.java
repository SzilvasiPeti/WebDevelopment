package com.example.WebShop.persistence;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;

import com.example.WebShop.models.Product;

@Component
public class ProductDao {

	private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("src/main/resources/databases/products.odb");

    private EntityManager entityManager = entityManagerFactory.createEntityManager();

    /*{
    	entityManager.getTransaction().begin();
		String ventilatorSummary = "The humidifier can optimize the temperature sensation! Perfect refreshment!";
		String ventilatorLeiras= "A pÃ¡rÃ¡sÃ­tÃ³ ventilÃ¡tor a legdurvÃ¡bb kÃ¡nikulÃ¡ban is kÃ©pes a hÅÃ©rzetet optimalizÃ¡lni! TÃ¶kÃ©letes felfrissÃ¼lÃ©s, mÃ©gsem leszel vizes!";
		entityManager.persist(new Product("Ventilator","VentilÃ¡tor", ventilatorSummary,ventilatorLeiras, 24990, 7, "/images/ventilator.jpg"));
		String reflektorSummary = "100 Watt COB LED panel mounted LED floodlight, in extra compact size, even to illuminate shop windows. With low heat output up to 90% lower power consumption!";
		String reflektorLeiras = "100 Wattos COB LED panellel szerelt ledes fÃ©nyvetÅ, extra kompakt mÃ©retben, akÃ¡r Ã¼zletek kirakatainak megvilÃ¡gÃ­tÃ¡sÃ¡ra is. Alacsony hÅtermelÃ©s mellett, akÃ¡r 90%-al alacsonyabb energiafogyasztÃ¡ssal!";
		entityManager.persist(new Product("Reflector","Reflektor", reflektorSummary,reflektorLeiras, 25990, 5, "/images/reflektor.jpg"));
		String cameraSummary = "2.7 inches display One-step detachable Full HD resolution of 1920x1080 pixels further resolutions: 1080FHD 1920x1080 @ 30fps.";
		String cameraLeiras = "2,7 inches kijelzÅ Egy mozdulattal levehetÅ Full HD felbontÃ¡s 1920x1080 pixel tovÃ¡bbi felbontÃ¡sok: 1080FHD 1920x1080@30fps.";
		entityManager.persist(new Product("Camera","Kamera", cameraSummary,cameraLeiras, 9990, 10, "/images/kamera.jpg"));
		String lampaSummary = "You no longer need to turn on the light after dark even if you want to use computer - The 28 LED USB light your keyboard well!";
		String lampaLeiras = "TÃ¶bbÃ© nem szÃ¼ksÃ©ges felkapcsolni a villanyt sÃ¶tÃ©tedÃ©s utÃ¡n sem, ha szÃ¡mÃ­tÃ³gÃ©pezni szeretne- A 28 LED-es USB lÃ¡mpa kivÃ¡lÃ³an megvilÃ¡gÃ­tja billentyÅ±zetÃ©t is!";
		entityManager.persist(new Product("Lamp","LÃ¡mpa", lampaSummary,lampaLeiras, 1490, 14, "/images/lampa.jpg"));
		String oraSummary = "The Hungarian menu has arrived, a full complement of phone accessories, which can be used as a speakerphone and you can make phone conversations with it!";
		String oraLeiras = "MegÃ©rkezett a magyar menÃ¼s, teljes Ã©rtÃ©kÅ± telefonkiegÃ©szÃ­tÅ, ami kihangosÃ­tÃ³kÃ©nt is hasznÃ¡lhatÃ³ Ã©s telefonbeszÃ©lgetÃ©seket is lebonyolÃ­thatsz vele!";
		entityManager.persist(new Product("Smart watch","OkosÃ³ra", oraSummary,oraLeiras, 19990, 6, "/images/okosora.jpg"));
		entityManager.getTransaction().commit();
    }*/

    public List<Product> getAllProducts() {
        TypedQuery<Product> query = entityManager.createQuery("SELECT product FROM Product product", Product.class);
        return query.getResultList();
    }


}
