package com.example.WebShop.persistence;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;

import com.example.WebShop.models.User;

@Component
public class UserDao {

	private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("src/main/resources/databases/users.odb");

    private EntityManager entityManager = entityManagerFactory.createEntityManager();

    private User user;

    /*{
	entityManager.getTransaction().begin();
		entityManager.persist(new User("Peter", "12345678a"));
		entityManager.persist(new User("Adam", "54321678a"));
		entityManager.persist(new User("Mate", "12543678a"));
		entityManager.persist(new User("Gabor", "34125678a"));
	entityManager.getTransaction().commit();
    }*/

    public List<User> getAllUsers() {
        TypedQuery<User> query = entityManager.createQuery("SELECT user FROM User user", User.class);
        return query.getResultList();
    }

    public void newPassword(String account, String password){
    	List<User> users = getAllUsers();
    	for(int i=0; i < users.size(); i++){
    		if(users.get(i).getAccount().equals(account)){
    			user = users.get(i);
    		}
    	}
    	entityManager.getTransaction().begin();
    	  user.setPwd(password);
    	entityManager.getTransaction().commit();
    }
    public void newUser(String account, String password){
		entityManager.getTransaction().begin();
			entityManager.persist(new User(account, password));
    	entityManager.getTransaction().commit();
    }
}
