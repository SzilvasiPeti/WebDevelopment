package com.example.WebShop.controllers;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.WebShop.models.Product;
import com.example.WebShop.models.User;
import com.example.WebShop.persistence.ProductDao;
import com.example.WebShop.persistence.UserDao;

@Controller
public class UserController {

	private static Logger LOGGER = LogManager.getLogger();
	private Cookie cookie1;
	private String language1;
	@Autowired
	private UserDao userDAO;
	private HttpSession accountSession;
	private String accountString;
	@Autowired
	private ProductDao productDAO;

	@RequestMapping(value = ("/"))
	public String Index(@CookieValue(required = false) String kuki1,@RequestParam(required=false) String language,HttpServletResponse response) {

		language = language1;
		if(kuki1 == null){
			language = "hu_HU";
		}
		else if(kuki1.equals("hu_HU")){
			language = "hu_HU";
			cookie1 = new Cookie("kuki1", language);
			response.addCookie(cookie1);
		}else if(kuki1.equals("en")){
			language = "en";
			cookie1 = new Cookie("kuki1", language);
			response.addCookie(cookie1);
		}
		language1 = language;
		return "index";
	}

	@RequestMapping(value = ("/login"))
	public String Login(@CookieValue(required = false) String kuki1,@RequestParam(required=false) String language,
			@RequestParam(required = false) String account, @RequestParam(required = false) String pwd, Model model, HttpServletResponse response, HttpServletRequest request) {
		List<User> userList = userDAO.getAllUsers();
		accountString = request.getParameter("account");

		accountSession = request.getSession();

		if(language1==null){
			language = "hu_HU";
			language1 = "hu_HU";
		}else if(language==null){
			language = language1;
		}
		language1=language;
		cookie1 = new Cookie("kuki1", language);
		response.addCookie(cookie1);

		if (accountSession.getAttribute("account")!=null) {
			return "logged";
		}
		if (pwd == null && account == null) {
			return "login";
		} else if(pwd.length() < 8){
			model.addAttribute("passwordLength", true);
			return "login";
		} else if(pwd.length() == 0){
			model.addAttribute("passwordNull", true);
			return "login";
		}else if (account != null && pwd != null) {
			for(int i=0; i< userList.size();i++){
				if(account.equals(userList.get(i).getAccount()) && pwd.equals(userList.get(i).getPwd())){
					accountSession.setAttribute("account", accountString);
					model.addAttribute("account", accountSession);

					LOGGER.info(accountString +" are logged in.");
					return "redirect:/logged?language="+language;
				}
			}
		}else{
			LOGGER.info("The password or username is wrong.");
			model.addAttribute("wrong", true);
			return "login";
		}
		return "login";
	}
	@RequestMapping("/logout")
    public String logout(@RequestParam(required=false) String language,@CookieValue(required = false) String kuki1,@CookieValue(required = false) String kuki, HttpServletResponse response, HttpServletRequest request){
		language1 = kuki1;

		accountSession = request.getSession();
		LOGGER.info(accountSession.getAttribute("account") + " are logged out.");
		accountSession.invalidate();

        return "redirect:/login?language="+kuki1;
    }

	@RequestMapping("/profile")
	public String Profile(@CookieValue(required = false) String kuki1,@RequestParam(required=false) String language,HttpServletResponse response){
		cookie1 = new Cookie("kuki1", language);
		response.addCookie(cookie1);
		return "profile";
	}

	@RequestMapping("/newPassword")
	public String newPassword(@CookieValue(required = false) String kuki1,@RequestParam(required = false) String pwd,HttpServletRequest request, Model model,@RequestParam(required=false) String language,HttpServletResponse response){
		userDAO.newPassword(accountString, pwd);
		LOGGER.info(accountString + "'s password is changed");
		List<Product> productList = productDAO.getAllProducts();
		model.addAttribute("list", productList);

		accountSession = request.getSession();
		accountSession.setAttribute("account", accountString);
		model.addAttribute("account", accountString);

		cookie1 = new Cookie("kuki1", language);
		response.addCookie(cookie1);
		return "redirect:/logged?language="+kuki1;
	}

	@RequestMapping("/registration")
	public String Registration(@CookieValue(required = false) String kuki1,@RequestParam(required=false) String language,HttpServletResponse response){
		cookie1 = new Cookie("kuki1", language);
		response.addCookie(cookie1);
		return "registration";
	}

	@RequestMapping("/newAccount")
	public String newAccount(@CookieValue(required = false) String kuki1,@RequestParam(required = false) String pwd,@RequestParam(required = false) String account,HttpServletRequest request, Model model,@RequestParam(required=false) String language,HttpServletResponse response){
		List<User> users = userDAO.getAllUsers();
		boolean allowed = true;
    	for(int i=0; i < users.size();i++){
    		if(users.get(i).getAccount().equals(account)){
    			allowed=false;
    		}
    	}
    	if(allowed == true){
    		userDAO.newUser(account, pwd);
    	}else{
        	model.addAttribute("sameAccount", true);
        	return "registration";
    	}
		LOGGER.info("New account name:"+account+" and your password:"+pwd);
		accountSession = request.getSession();
		accountSession.setAttribute("account", accountString);
		model.addAttribute("account", accountString);

		cookie1 = new Cookie("kuki1", language);
		response.addCookie(cookie1);
		return "redirect:/login?language="+kuki1;
	}

	@RequestMapping("/products")
	public String ProductList(@CookieValue(required = false) String kuki1,@RequestParam(required=false) String language){
		return "redirect:/logged?language="+kuki1;
	}

	public String getLanguage1() {
		return language1;
	}

	public Cookie getCookie1() {
		return cookie1;
	}

}
