import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { appRouting } from './app.routing';
import {AppComponent} from './app.component';
import {UserProfileComponent} from './users/user-profile.component';
import {UserFormComponent} from './users/user-form.component';
import { HomeComponent } from './home/home.component';
import { MenuComponent } from './menu/menu.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { AboutComponent } from './about/about.component';
import { RestaurantComponent } from './restaurant/restaurant.component';
import { LoginComponent } from './login/login.component';
import { ComplexFormComponent } from './login/complexform.component';

@NgModule({
	imports: [
		BrowserModule,
		FormsModule,
		ReactiveFormsModule,
		appRouting
	],
	declarations: [
		AppComponent,
		UserProfileComponent,
		UserFormComponent,
		HomeComponent,
		MenuComponent,
		AboutComponent,
		RestaurantComponent,
		LoginComponent,
		NotFoundComponent,
		ComplexFormComponent
	],
	bootstrap: [AppComponent]
})
export class AppModule{}