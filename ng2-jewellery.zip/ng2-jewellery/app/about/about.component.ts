import { Component } from '@angular/core';

@Component({
	selector: 'about-page',
	template: `
		<p>It is the about page.</p>
	`

})
export class AboutComponent{}