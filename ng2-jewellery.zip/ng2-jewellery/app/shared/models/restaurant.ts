export class Restaurant{
	name:string;
	url:string;
	phoneNumber:string;
	rating:number;
	ratingCount:number;
	ownerName:string;
	description:string;
	deliveryFreeAbove:number;
	minPurchase:number;
	homeDelivery:boolean;
}