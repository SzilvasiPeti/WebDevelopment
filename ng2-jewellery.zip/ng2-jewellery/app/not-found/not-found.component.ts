import { Component } from '@angular/core';

@Component({
	template: `
	<div class="jumbptrpn text-center">
		<h1>404 Not Found</h1>
		<p>You may be lost. Follow the breadscrumbs back <a routerLink="/">Home</a>.</p>
		</div>
	`
})
export class NotFoundComponent{}