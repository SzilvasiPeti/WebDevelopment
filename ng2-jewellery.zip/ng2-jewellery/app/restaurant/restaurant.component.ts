import { Component } from '@angular/core';
import { Restaurant } from '../shared/models/restaurant';

@Component({
	selector: 'restaurant-page',
	templateUrl: "./app/restaurant/restaurant.component.html"

})
export class RestaurantComponent{

	restaurants:Restaurant[] = [
		{name:'Végállomás Bistorant', url:'http://vegallomasetterem.hu/', phoneNumber:'0646402952', rating:5, ratingCount:179, ownerName:'Várvizi Péter', description:'', deliveryFreeAbove:5000, minPurchase:1100, homeDelivery:true},

		{name:'Creppy PalacsintaHáz Étterem', url:'http://creppy.hu/', phoneNumber:'06703743671', rating:4.5, ratingCount:253, ownerName:'Kovács János', description:'', deliveryFreeAbove:null, minPurchase:null, homeDelivery:false},

		{name:'Rossita Pizza Miskolc', url:"http://rossita.hu/", phoneNumber:'0646344300', rating:5, ratingCount:73, ownerName:'Tóth Béla', description:'', deliveryFreeAbove:1500, minPurchase:500, homeDelivery:true}
		
	];
}