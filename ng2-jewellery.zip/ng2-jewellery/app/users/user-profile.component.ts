import { Component, Input } from '@angular/core';
import { User } from '../shared/models/user';

@Component({
	selector: 'user-profile',
	template:`
	<div class="jumbotron" *ngIf="user1">
		<h2>{{ user1.name}} {{user1.email}} <small>{{user1.password}} {{user1.phone}}</small></h2>
	
		<input class="form-control" [(ngModel)]="user1.name">
	</div>

	`
})
export class UserProfileComponent {
	@Input() user1: User;
}