import { Component } from '@angular/core';
import {User} from './shared/models/user';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
	selector: "my-app",
	templateUrl: './app/app.component.html',
  	styleUrls: ['./app/app.component.css']

})
export class AppComponent {
	modelOpen: boolean = false;
	LoginForm : FormGroup;

	 constructor(fb: FormBuilder){
	 	this.LoginForm = fb.group({
	 		'email': [null,  Validators.compose([Validators.required, Validators.pattern('[a-zA-z0-9]+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}')])]
	 	});
  	}
}