import { Component } from '@angular/core';

@Component({
	selector: 'menu-page',
	template: `
		<p>It is the menu page.</p><small>http://rossita.hu/etelek-italok/</small>
	`
})
export class MenuComponent{}