import { Component, Output, Input, EventEmitter } from '@angular/core';
import{ User } from '../shared/models/user';
// We will need to import a couple of specific API’s for dealing with reactive forms
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'complex-form',
  templateUrl : './app/login/complexform.component.html'
})
export class ComplexFormComponent {
  complexForm : FormGroup;
  @Output() userCreated = new EventEmitter();
  newUser: User = new User();
  active: boolean = true;

  constructor(fb: FormBuilder){
    this.complexForm = fb.group({
      'name' : [null, Validators.required],
      'email': [null,  Validators.compose([Validators.required, Validators.pattern('[a-zA-z0-9]+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}')])],
      'address': [null, Validators.required],
      'phone': [null, Validators.compose([Validators.required, Validators.pattern('[0-9]{11}')])],
      'password' : [null,  Validators.compose([Validators.required, Validators.minLength(8), Validators.pattern('(?:[0-9]+[a-z]|[a-z]+[0-9])[a-z0-9]*')])],
      'confirmpassword': [null, Validators.required]
      /*'hiking' : [false],
      'running' : [false],
      'swimming' : [false]*/

    /*console.log(this.complexForm);
    this.complexForm.valueChanges.subscribe( (form: any) => {
      //console.log('form changed to:', form);
    }
    );*/
    });
  }
  submitForm(value: any){
    console.log(value);
    console.log(this.newUser);

    this.userCreated.emit({user: this.newUser});

    this.newUser = new User();
    this.active = false;
    setTimeout(() => this.active = true, 0);
    this.complexForm.reset();
  }
}