import { Component, Input } from '@angular/core';
import { User } from '../shared/models/user';
import { ComplexFormComponent } from '../login/complexform.component';

@Component({
	selector: 'login-page',
	template: `
	<complex-form (userCreated)="onUserCreated($event)"></complex-form>
	<div *ngIf="users">
	  <ul class="list-group user-list">
	    <li class="list-group-item" 
	      *ngFor="let user of users" 
	      (click)="selectUser(user)"
	      [class.active]="user === activeUser">
	    {{user.name}} <i>{{user.password}}</i>
	    </li>
	  </ul>
	</div>
  	<!--<div class="row">
    <div class="col-sm-4">
      <div *ngIf="users1">
      <ul class="list-group user-list">
        <li class="list-group-item" 
          *ngFor="let user1 of users1" 
          (click)="selectUser1(user1)"
          [class.active]="user1 === activeUser1">
        {{user1.name}} <i>{{user1.password}}</i>
        </li>
      </ul>
      </div>
      <user-form (userCreated1)="onUserCreated1($event)"></user-form>
    </div>
    <div class="col-sm-8">

    <user-profile [user1]="activeUser1"></user-profile>

      <div class="jumbotron createUser" *ngIf="!activeUser1">
        <span class="glyphicon glyphicon-hand-left"></span>
        <h2>Create User</h2>
      </div>

    </div>
  </div>-->
  
	`,
	styleUrls: ['../app/login/login.component.css']
})
export class LoginComponent{
	//@Input() user1;
	@Input() user;
	users: User[] = [];
	/*users1: User[] = [
		{name: 'Peter', email: 'peter@gmail.com', phone: '06301234567', address: 'Miskolc', password: '12345'},
		{name: 'Nick', email: 'nick@gmail.com', phone: '06701234567', address: 'Debrecen', password: '123456'},
		{name: 'Holly', email: 'holly@gmail.com', phone: '06201234567', address: 'Budapest', password: '1234567'}
	];*/
	//activeUser1: User;
	activeUser: User;

	/*selectUser1(user1){
		this.activeUser1 = user1;
		console.log(this.activeUser1);
	}

	onUserCreated1(event){
		this.users1.push(event.user1);
	}*/

	selectUser(user){
		this.activeUser = user;
		console.log(this.activeUser);
	}

	onUserCreated(event){
		this.users.push(event.user);
	}
}